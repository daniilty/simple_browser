package com.example.listactdemo;

import android.annotation.SuppressLint;
import android.app.ListActivity;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements TextWatcher {
    private WebView sid;
    private static final String[] arr = {"https://"};
    private AutoCompleteTextView auc;
    private LinearLayout lin;
    private ProgressBar bar;
    private Button bute;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sid = findViewById(R.id.webview);
        bar = findViewById(R.id.progressBar3);
        sid.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                bar.setVisibility(View.VISIBLE);

            }

            public void onPageFinished(WebView view, String url) {
                bar.setVisibility(View.GONE);

            }

            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                bar.setVisibility(View.GONE);

            }
        });
        auc = findViewById(R.id.texa);
        auc.addTextChangedListener(this);
        auc.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_dropdown_item_1line,arr));
        sid.getSettings().setJavaScriptEnabled(true);
        sid.loadUrl("https://google.com");


    }

    public void setvis(View view) {
        lin = findViewById(R.id.lin);
        lin.setVisibility(View.VISIBLE);

    }

    @Override
    public void onBackPressed() {
        if (sid.canGoBack()) {
            sid.goBack();
            return;
        }

        // Otherwise defer to system default behavior.
        super.onBackPressed();
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {

    }
    public void opa(View view) {
        sid.loadUrl((auc.getText()).toString());
        lin = findViewById(R.id.lin);
        lin.setVisibility(View.INVISIBLE);
    }
    public void refreshdemo(View view) {
        sid.reload();

    }
    public void forw(View view) {
        if(sid.canGoForward()) {
            sid.goForward();
        }
    }
}
